﻿namespace CODICE_FISCALE
{
    partial class Form1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.labelNome = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.labelLuogo = new System.Windows.Forms.Label();
            this.textBoxCognome = new System.Windows.Forms.TextBox();
            this.textBoxLuogo = new System.Windows.Forms.TextBox();
            this.textBoxNome = new System.Windows.Forms.TextBox();
            this.comboBoxSesso = new System.Windows.Forms.ComboBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxRisultato = new System.Windows.Forms.TextBox();
            this.buttonCalcola = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Noto Naskh Arabic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(502, 27);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(408, 41);
            this.label1.TabIndex = 0;
            this.label1.Text = "CALCOLO CODICE FISCALE";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(363, 120);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(128, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "COGNOME:";
            // 
            // labelNome
            // 
            this.labelNome.AutoSize = true;
            this.labelNome.Location = new System.Drawing.Point(410, 174);
            this.labelNome.Name = "labelNome";
            this.labelNome.Size = new System.Drawing.Size(81, 25);
            this.labelNome.TabIndex = 3;
            this.labelNome.Text = "NOME:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(820, 174);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 25);
            this.label5.TabIndex = 4;
            this.label5.Text = "SESSO:";
            // 
            // labelLuogo
            // 
            this.labelLuogo.AutoSize = true;
            this.labelLuogo.Location = new System.Drawing.Point(276, 235);
            this.labelLuogo.Name = "labelLuogo";
            this.labelLuogo.Size = new System.Drawing.Size(215, 25);
            this.labelLuogo.TabIndex = 5;
            this.labelLuogo.Text = "LUOGO DI NASCITA:";
            // 
            // textBoxCognome
            // 
            this.textBoxCognome.Location = new System.Drawing.Point(509, 117);
            this.textBoxCognome.Name = "textBoxCognome";
            this.textBoxCognome.Size = new System.Drawing.Size(156, 31);
            this.textBoxCognome.TabIndex = 6;
            // 
            // textBoxLuogo
            // 
            this.textBoxLuogo.Location = new System.Drawing.Point(509, 229);
            this.textBoxLuogo.Name = "textBoxLuogo";
            this.textBoxLuogo.Size = new System.Drawing.Size(156, 31);
            this.textBoxLuogo.TabIndex = 7;
            // 
            // textBoxNome
            // 
            this.textBoxNome.Location = new System.Drawing.Point(509, 174);
            this.textBoxNome.Name = "textBoxNome";
            this.textBoxNome.Size = new System.Drawing.Size(156, 31);
            this.textBoxNome.TabIndex = 8;
            // 
            // comboBoxSesso
            // 
            this.comboBoxSesso.FormattingEnabled = true;
            this.comboBoxSesso.Items.AddRange(new object[] {
            "M",
            "F"});
            this.comboBoxSesso.Location = new System.Drawing.Point(916, 171);
            this.comboBoxSesso.Name = "comboBoxSesso";
            this.comboBoxSesso.Size = new System.Drawing.Size(42, 33);
            this.comboBoxSesso.TabIndex = 9;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(509, 287);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(318, 31);
            this.dateTimePicker1.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(295, 293);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(196, 25);
            this.label3.TabIndex = 11;
            this.label3.Text = "DATA DI NASCITA:";
            // 
            // textBoxRisultato
            // 
            this.textBoxRisultato.Location = new System.Drawing.Point(553, 427);
            this.textBoxRisultato.Name = "textBoxRisultato";
            this.textBoxRisultato.Size = new System.Drawing.Size(318, 31);
            this.textBoxRisultato.TabIndex = 12;
            // 
            // buttonCalcola
            // 
            this.buttonCalcola.Location = new System.Drawing.Point(638, 367);
            this.buttonCalcola.Name = "buttonCalcola";
            this.buttonCalcola.Size = new System.Drawing.Size(144, 33);
            this.buttonCalcola.TabIndex = 13;
            this.buttonCalcola.Text = "Calcola";
            this.buttonCalcola.UseVisualStyleBackColor = true;
            this.buttonCalcola.Click += new System.EventHandler(this.buttonCalcola_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.buttonCalcola);
            this.Controls.Add(this.textBoxRisultato);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.comboBoxSesso);
            this.Controls.Add(this.textBoxNome);
            this.Controls.Add(this.textBoxLuogo);
            this.Controls.Add(this.textBoxCognome);
            this.Controls.Add(this.labelLuogo);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.labelNome);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "Form1";
            this.Text = "Codice fiscale";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label labelNome;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label labelLuogo;
        private System.Windows.Forms.TextBox textBoxCognome;
        private System.Windows.Forms.TextBox textBoxLuogo;
        private System.Windows.Forms.TextBox textBoxNome;
        private System.Windows.Forms.ComboBox comboBoxSesso;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxRisultato;
        private System.Windows.Forms.Button buttonCalcola;
    }
}

