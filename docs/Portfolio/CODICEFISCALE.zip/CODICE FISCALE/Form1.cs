﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CODICE_FISCALE
{
    public partial class Form1 : Form
    {
        Dictionary<string,string> mappaComuni = new Dictionary<string, string>();
        public Form1()
        {
            InitializeComponent();
            InizializzaMappaComuni();
        }
        private void InizializzaMappaComuni()
        {
            mappaComuni.Add("TORINO", "L219");
            mappaComuni.Add("CEFALU", "C421");
            mappaComuni.Add("MILANO", "F205");
        }
        private bool isVocale(char carattere)
        {
            carattere = Char.ToLower(carattere);
            return carattere == 'a' || carattere == 'e' || carattere == 'i' || carattere == 'o' || carattere == 'u';
        }
        private string getCodiceCognome(string cognome) {
            string codiceCognome = "";
            foreach (char c in cognome)
            {
                if (!isVocale(c))
                {
                    codiceCognome+= c;

                }
            }
            return codiceCognome.ToUpper().Substring(0, 3);

        }
        private string getCodiceLuogo(string luogoNascita)
        {
            string codiceLuogo = "";
            luogoNascita=luogoNascita.ToUpper();
            codiceLuogo = mappaComuni[luogoNascita];
            return codiceLuogo;
        }
        private string getCodiceNome(string nome)
        {
            string codiceNome = "";
            foreach (char c in nome)
            {
                if (!isVocale(c))
                {
                    codiceNome += c;

                }
            }
            return codiceNome.ToUpper().Substring(0, 3);

        }
        private string getLetteraMese(string numeroMese)
        {
            if (numeroMese == "01")
            {
                return "A";
            }
            else if(numeroMese == "02")
            {
                return "B";
            }
            else if (numeroMese == "02")
            {
                return "B";
            }
            else if (numeroMese == "03")
            {
                return "C";
            }
            else if (numeroMese == "04")
            {
                return "D";
            }
            else if (numeroMese == "05")
            {
                return "E";
            }
            else if (numeroMese == "06")
            {
                return "H";
            }
            else if (numeroMese == "07")
            {
                return "L";
            }
            else if (numeroMese == "08")
            {
                return "M";
            }
            else if (numeroMese == "09")
            {
                return "P";
            }
            else if (numeroMese == "10")
            {
                return "R";
            }
            else if (numeroMese == "11")
            {
                return "S";
            }
            else if (numeroMese == "12")
            {
                return "T";
            }
            return "";
        }

        private string getGiorno(string giorno,string sesso)
        {
            int g = Int32.Parse(giorno);
            if (sesso == "F")
            {
                g += 40;
            }
            return "" + ( g < 10 ? "0": "") + g.ToString();
        }
        private string getCodiceData(string data,string sesso)
        {
            string codiceData = "";
            codiceData += data.Substring(2, 2);
            codiceData += getLetteraMese(data.Substring(5, 2));
            codiceData += getGiorno(data.Substring(8, 2), sesso);

            return codiceData;

        }
        private int getValoriDispari(char valore)
        {
            Dictionary<char,int> mappa= new Dictionary<char,int>();
            mappa.Add('0', 1);
            mappa.Add('1', 0);
            mappa.Add('2', 5);
            mappa.Add('3', 7);
            mappa.Add('4', 9);
            mappa.Add('5', 13);
            mappa.Add('6', 15);
            mappa.Add('7', 17);
            mappa.Add('8', 19);
            mappa.Add('9', 21);
            mappa.Add('A', 1);
            mappa.Add('B', 0);
            mappa.Add('C', 5);
            mappa.Add('D', 7);
            mappa.Add('E', 9);
            mappa.Add('F', 13);
            mappa.Add('G', 15);
            mappa.Add('H', 17);
            mappa.Add('I', 19);
            mappa.Add('J', 21);
            mappa.Add('K', 2);
            mappa.Add('L', 4);
            mappa.Add('M', 18);
            mappa.Add('N', 20);
            mappa.Add('O', 11);
            mappa.Add('P', 3);
            mappa.Add('Q', 6);
            mappa.Add('R', 8);
            mappa.Add('S', 12);
            mappa.Add('T', 14);
            mappa.Add('U', 16);
            mappa.Add('V', 10);
            mappa.Add('W', 22);
            mappa.Add('X',25);
            mappa.Add('Y', 24);
            mappa.Add('Z', 23);
            return mappa[valore];
        }
        private int getValoriPari(char valore)
        {
            Dictionary<char, int> mappa = new Dictionary<char, int>();
            mappa.Add('0', 0);
            mappa.Add('1', 1);
            mappa.Add('2', 2);
            mappa.Add('3', 3);
            mappa.Add('4', 4);
            mappa.Add('5', 5);
            mappa.Add('6', 6);
            mappa.Add('7', 7);
            mappa.Add('8', 8);
            mappa.Add('9', 9);
            mappa.Add('A', 0);
            mappa.Add('B', 1);
            mappa.Add('C', 2);
            mappa.Add('D', 3);
            mappa.Add('E', 4);
            mappa.Add('F', 5);
            mappa.Add('G', 6);
            mappa.Add('H', 7);
            mappa.Add('I', 8);
            mappa.Add('J', 9);
            mappa.Add('K', 10);
            mappa.Add('L', 11);
            mappa.Add('M', 12);
            mappa.Add('N', 13);
            mappa.Add('O', 14);
            mappa.Add('P', 15);
            mappa.Add('Q', 16);
            mappa.Add('R', 17);
            mappa.Add('S', 18);
            mappa.Add('T', 19);
            mappa.Add('U', 20);
            mappa.Add('V', 21);
            mappa.Add('W', 22);
            mappa.Add('X', 23);
            mappa.Add('Y', 24);
            mappa.Add('Z', 25);
            return mappa[valore];
        }
        private char convertiValore(int totale)
        {
            int valore = totale % 26;
            Dictionary<int, char> mappa = new Dictionary<int, char>();
            mappa.Add(0, 'A');
            mappa.Add(1, 'B');
            mappa.Add(2, 'C');
            mappa.Add(3, 'D');
            mappa.Add(4, 'E');
            mappa.Add(5, 'F');
            mappa.Add(6, 'G');
            mappa.Add(7, 'H');
            mappa.Add(8, 'I');
            mappa.Add(9, 'J');
            mappa.Add(10, 'K');
            mappa.Add(11, 'L');
            mappa.Add(12, 'M');
            mappa.Add(13, 'N');
            mappa.Add(14, 'O');
            mappa.Add(15, 'P');
            mappa.Add(16, 'Q');
            mappa.Add(17, 'R');
            mappa.Add(18, 'S');
            mappa.Add(19, 'T');
            mappa.Add(20, 'U');
            mappa.Add(21, 'V');
            mappa.Add(22, 'W');
            mappa.Add(23, 'X');
            mappa.Add(24, 'Y');
            mappa.Add(25, 'Z');
            return mappa[valore];

        }
        private char getUltimoCarattere(string codiceFiscale) {
            char  ultimoCarattere;
            int i = 1;
            int totale = 0;
            foreach(char c in codiceFiscale)
            {
                if (i % 2 == 0)
                {
                    totale += getValoriPari(c);
                }
                else
                {
                    totale += getValoriDispari(c);
                }
                i++;
            }
            ultimoCarattere = convertiValore(totale);
            return ultimoCarattere;
        }

        private void buttonCalcola_Click(object sender, EventArgs e)
        {
            if (textBoxNome.Text.Length < 2)
            {
                SystemSounds.Exclamation.Play();
                MessageBox.Show("Alcuni campi non risultano compilati!", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (System.Text.RegularExpressions.Regex.IsMatch(textBoxNome.Text, @"^[a-zA-Z]+$") == false)
            {
                SystemSounds.Exclamation.Play();
                MessageBox.Show("il campo 'Nome'contiene caratteri non validi", "ERRORE", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            if (textBoxCognome.Text.Length < 2)
            {
                SystemSounds.Exclamation.Play();
                MessageBox.Show("Alcuni campi non risultano compilati!", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (System.Text.RegularExpressions.Regex.IsMatch(textBoxCognome.Text, @"^[a-zA-Z]+$") == false)
            {
                SystemSounds.Exclamation.Play();
                MessageBox.Show("il campo 'Cognome'contiene caratteri non validi", "ERRORE", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            if (textBoxLuogo.Text.Length < 2)
            {
                SystemSounds.Exclamation.Play();
                MessageBox.Show("Alcuni campi non risultano compilati!", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (System.Text.RegularExpressions.Regex.IsMatch(textBoxLuogo.Text, @"^[a-zA-Z]+$") == false)
            {
                SystemSounds.Exclamation.Play();
                MessageBox.Show("il campo 'Luogo'contiene caratteri non validi", "ERRORE", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            if (comboBoxSesso.SelectedItem == null)
            {
                SystemSounds.Exclamation.Play();
                MessageBox.Show("Alcuni campi non risultano compilati!", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            string codiceFiscale = "";
            codiceFiscale += getCodiceCognome(textBoxCognome.Text);
            codiceFiscale += getCodiceNome(textBoxNome.Text);
            codiceFiscale += getCodiceData(dateTimePicker1.Value.ToString("yyyy-MM-dd"),comboBoxSesso.SelectedItem.ToString());
            codiceFiscale += getCodiceLuogo(textBoxLuogo.Text);
            codiceFiscale += getUltimoCarattere(codiceFiscale);
            textBoxRisultato.Text= codiceFiscale; 
        }
    }
}
